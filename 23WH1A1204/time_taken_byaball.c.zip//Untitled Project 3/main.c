#include <stdio.h>
#include<math.h>

int main() {
    float s,t,u,a;
    s=(10*3);
    u=0.0;
    a=9.8;
    t=sqrt(2*s/a);
    printf("time taken is %f",t);

    return 0;
}