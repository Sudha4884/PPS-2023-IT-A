#include <stdio.h>

int main() {
    // Declare variable
    int n;

    // Input from the user
    printf("Enter a value of n: ");
    scanf("%d", &n);

    // Validate input
    if (n <= 1) {
        printf("Please enter a value of n greater than 1.\n");
        return 1;  // Exit program with an error code
    }

    // Display prime numbers between 1 and n
    printf("Prime numbers between 1 and %d are:\n", n);
    for (int i = 2; i <= n; i++) {
        int isPrime = 1; // Assume i is prime

        for (int j = 2; j * j <= i; j++) {
            if (i % j == 0) {
                isPrime = 0; // i is not prime
                break;
            }
        }

        if (isPrime) {
            printf("%d\n", i);
        }
    }

    return 0;
}
