#include <stdio.h>


void main()
{
    int d;
    printf("enter a number");
    scanf("%d",&d);
    

    int binary[8];  
    int i;

    for (i = 7; i >= 0; i--) {
        binary[i] = d % 2;
        d /= 2;
    }


    for (i = 0; i < 8; i++) {
        printf("%d", binary[i]);
    }
    printf("\n");
}
