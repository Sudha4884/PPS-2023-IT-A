/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#define findelectricitybill E
float E(int);
void
main ()
{
  int units;
  char name[20];
  printf ("enter name , units");
  scanf ("%s", name);
  scanf ("%d", &units);
  printf ("\n%s", name);
  E (units);
  printf ("\n%f", E (units));



}

float E(int u)
{
  float b = 0;			// b=bill
  if (u >= 600)
    b = 2 * (u - 600) + (1.8 + 1.5 + 1.2) * 199;
  else if (u >= 400)
    b = 1.8 * (u - 400) + (1.5 + 1.2) * 199;
  else if (u >= 200)
    b = 1.5 * (u - 200) + (1.2) * 199;
  else
    b = b * (1.20);
  if (b < 100)
    b = 100;
  else if (b > 400)
    b = b + (0.15) * b;
  return b;
}
